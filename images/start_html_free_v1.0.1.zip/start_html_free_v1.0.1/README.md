# Start HTML Free  - Bootstrap 5 HTML Multipurpose Admin Dashboard Template

- For a quick start please check [Online documentation](//preview.keenthemes.com/start-html-free/documentation/getting-started.html)

- The offline documentation is available here [Offline documentation](//theme/dist/documentation/getting-started.html)

- To learn more about the product license, please check out LICENSE file or [Product Licenses](//keenthemes.com/licensing)

- Check out our market for more products: [Keenthemes Market](//keenthemes.com)

- For more amazing features and solutions, please upgrade to [Start HTML Pro](//keenthemes.com/products/start-html-pro)

- Stay tuned for updates via [Twitter](//www.twitter.com/keenthemes), [Instagram](//www.instagram.com/keenthemes), [Dribbble](//dribbble.com/keenthemes) and [Facebook](//facebook.com/keenthemes)

Happy coding with Start HTML Free!