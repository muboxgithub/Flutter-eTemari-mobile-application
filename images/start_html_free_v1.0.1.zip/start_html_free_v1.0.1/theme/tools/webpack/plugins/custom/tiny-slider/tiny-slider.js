
import {tns} from 'tiny-slider/src/tiny-slider';
import 'tiny-slider/src/tiny-slider.scss';